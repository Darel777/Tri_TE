#ifndef CRAGE_COMPILE_H
#define CRAGE_COMPILE_H

#define CRAGE_VERSION		_T("0.4.14.1")
#define CRAGE_RELEASE_TIME	_T("2009-7-24 11:29")
#define CRAGE_AUTHOR		_T("�՝h���\ <jzhang0@qq.com>")
#define CRAGE_RELEASE		_T("http://galcrass.blog124.fc2.com/")
#define CRAGE_SYNTEX		_T("[[-d dir] | [-p package_file]]\n\t")	\
		_T("\t[-l index_file] [-u cui_name] [-o output_dir]\n\t")	\
		_T("\t  [-n] [-v] [-r] [-h] [-I cui_name] [-i]")

#endif
