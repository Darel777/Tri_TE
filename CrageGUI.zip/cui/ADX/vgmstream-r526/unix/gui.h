#ifndef __GUI__
#define __GUI__

void vgmstream_gui_about();
void vgmstream_gui_configure();

#endif
